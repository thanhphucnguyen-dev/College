set dateformat dmy

create database Tuyen_dung3
use Tuyen_dung3

create table UNG_VIEN (
	MA_UV int primary key CHECK (MA_UV>0),
	HO_UV varchar(18) not null,
	TEN_UV varchar(18) not null,
	NGAY_S date not null,
	PHAI_NAM bit not null,
	SO_CMND varchar(15) not null,
	NGAY_CAP_CMND date CHECK (NGAY_CAP_CMND<getdate()),
	SO_DT_DD varchar(13),
	SO_DT_NHA varchar(16),
	SO_NHA varchar(10),
	DUONG varchar(50),
	MA_PHUONG_XA varchar(6) not null references DIA_PHUONG(MA_DP),
	TEN_PHUONG_XA varchar(30)
)

create table DON_TUYEN_DUNG (
	STT_DON int primary key CHECK (STT_DON>0),
	NGAY_GIO_NOP date not null CHECK (NGAY_GIO_NOP<=getdate()),
	MA_UV int not null references UNG_VIEN,
	MA_VT char(6) not null references VI_TRI_TUYEN,
	MA_CQ char(6) not null references CO_QUAN
)

create table CAP_DP (
	MA_CAP varchar(3) primary key CHECK (MA_CAP in ('PX', 'QH', 'TTP', 'TW')),
	TEN_CAP varchar(15) not null unique
)


create table DIA_PHUONG (
	MA_DP varchar(6) primary key ,
	TEN_DP varchar(15) not null,
	MA_CAP_DP varchar(3) references CAP_DP,
	MA_DP_TRUC_THUOC varchar(6) references DIA_PHUONG,
	TEN_DP_TRUC_THUOC varchar(15)
)



create table VI_TRI_TUYEN (
	MA_VT char(6) primary key,
	TEN_CHUC_VU varchar(15) not null,
	TEN_DON_VI varchar(40) not null
	unique(TEN_CHUC_VU, TEN_DON_VI)
)

create table CO_QUAN (
	MA_CQ char(6) primary key,
	TEN_CQ varchar(60) not null,
	MA_DP varchar(6) references DIA_PHUONG
)


insert into CAP_DP values ('PX', 'Phuong xa')
insert into CAP_DP values ('QH', 'Quan huyen')
insert into CAP_DP values ('TTP', 'Tinh- thanh pho')
insert into CAP_DP values ('TW', 'Trung uong')

select * from CAP_DP

insert into DIA_PHUONG values ('VL', 'Vinh Long', 'TTP', 'VL', null)
insert into DIA_PHUONG values ('LH', 'Long Ho', 'QH', 'VL', 'Vinh Long')
insert into DIA_PHUONG values ('LH001', 'Hoa Phu', 'PX', 'LH', 'Long Ho')
insert into DIA_PHUONG values ('CT', 'Can Tho', 'TTP', 'CT', null)
insert into DIA_PHUONG values ('PD', 'Phong Dien', 'QH', 'CT', 'Can Tho')
insert into DIA_PHUONG values ('PD001', 'Hoa Phu', 'PX', 'LH', 'Long Ho')
insert into DIA_PHUONG values ('LH001', 'Hoa An', 'PX', 'LH', 'Long Ho')

select * from DIA_PHUONG

insert into CO_QUAN values ('STP', 'So Tu phap', 'VL')
insert into CO_QUAN values ('PNN', 'Phong Nong nghiep', 'PD')
insert into CO_QUAN values ('PNNPD', 'Phong Nong nghiep', 'PD')
delete from CO_QUAN where MA_CQ='PNN'

select * from CO_QUAN

insert into VI_TRI_TUYEN values ('PGD', 'Pho Giam doc', 'Ban GD')
insert into VI_TRI_TUYEN values ('PP', 'Pho phong', 'Phong Cong chung')
insert into VI_TRI_TUYEN values ('TP', 'Truong phong', 'Phong Cong chung')


select * from VI_TRI_TUYEN

insert into UNG_VIEN values (1, 'Lam Tran', 'Mac', CONVERT(date, '20/09/1976'), 1, '025415783', CONVERT(date, '20/1/1991'), '0903245178', null, '21C', 'Le Thanh Ton', 'PD001', 'Hoa Phu')

select * from UNG_VIEN

insert into DON_TUYEN_DUNG values (1, CONVERT(date, '20/09/2015'), 1, 'TP', 'PNNPD')

select * from DON_TUYEN_DUNG
